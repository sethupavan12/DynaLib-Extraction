/*
 * Non-Degree Granting Education License -- for use at non-degree
 * granting, nonprofit, educational organizations only. Not for
 * government, commercial, or other organizational use.
 * File: compile_initialize.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 03-Mar-2022 10:38:07
 */

#ifndef COMPILE_INITIALIZE_H
#define COMPILE_INITIALIZE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void compile_initialize(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for compile_initialize.h
 *
 * [EOF]
 */
