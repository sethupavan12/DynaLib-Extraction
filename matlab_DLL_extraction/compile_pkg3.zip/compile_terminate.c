/*
 * Non-Degree Granting Education License -- for use at non-degree
 * granting, nonprofit, educational organizations only. Not for
 * government, commercial, or other organizational use.
 * File: compile_terminate.c
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 03-Mar-2022 10:38:07
 */

/* Include Files */
#include "compile_terminate.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void compile_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for compile_terminate.c
 *
 * [EOF]
 */
